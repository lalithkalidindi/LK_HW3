#-------------------------------------------------------------------------------
# HA3
# Student Name: LK Kalidindi
# Python version: 
# Submission Date: 10/30/2026
#-------------------------------------------------------------------------------
# Honor Code Statement: I received no assistance on this assignment that
# violates the ethical guidelines as set forth by the
# instructor and the class syllabus.
#-------------------------------------------------------------------------------
# References: 
#-------------------------------------------------------------------------------
# Notes to grader: 
#-------------------------------------------------------------------------------
# Source code below
#-------------------------------------------------------------------------------
#define Invalidcourse
class InvalidCourse(Exception):
    def __str__(self):
        return 'Course not found!'
 
# making the invalid Instructor
class InvalidInstructor(Exception):
    # making a function 
    def __str__(self):
        return "Instructor not found!"
 
# making the class InvalidLevel
class InvalidLevel(Exception):
    # making a function
    def __str__(self):
        # making a return statment of the course is not found
        return "Course level not found!"
 
# creating the class called option that is invalid
class InvalidOption(Exception):
    #making the function  string option
    def __str__(self):
        return "Invalid Option. Returning to main..."
 
# making the courseList class
class CourseList(list):
    # making a function called search with self statment key, and the creiteria of the course
    def search(self, key, criteria):
        # making results as an empty list
        results = []
 
        # making a for loop of the course
        for course in self:
            # making a if statment of the criteria and the course title
            if criteria == 't' and course.title == key:
                # putting a append function of the course
                results.append(course)
 
            # making elif statment of the critera and the course instructor
            elif criteria == 'i' and course.instructor == key:
                # making the append function of the courses
                results.append(course)
 
            elif criteria == 'l' and course.level == key:
                results.append(course)
 
        # returns the results
        return results
 
# making the class called courses
class Course(object):
    # making the all courses of the list of courses
    all_courses = CourseList()
 
    # making a function of the init
    def __init__(self, level, course_id, title, instructor):
        #making self level
        self.level = level
 
        #making a self of course_id of course_id
        self.course_id = course_id
 
        # making self of title
        self.title = title
 
        # making self for instructor
        self.instructor = instructor
 
        # making an append function of all courses
        Course.all_courses.append(self)
 
    def __str__(self):
        #return the all of the information about the course 
        return (f"Level #: {self.level}\n"
                f"ID: {self.course_id}\n"
                f"Title: {self.title}\n"
                f"Instructor: {self.instructor}")
 
# making a class called online **
class Online(Course):
 
    #making the function __init__
    def __init__(self, level, course_id, title, instructor):
        super().__init__(level, course_id, title, instructor)
        self.location = "Online"
 
    def __str__(self):
        # making super of the string
        base = super().__str__()
 
        # making return base of the online location
        return base + "\nLocation: Online"
 
# making the class called InPerson
class InPerson(Course):
    # making the function called __init__
    def __init__(self, level, course_id, title, instructor, campus, room, capacity):
        super().__init__(level, course_id, title, instructor)
 
        self.campus = campus # location of the campus
        self.room = room # room at the campus
        self.capacity = capacity
 
    # make the str
    def __str__(self):
        # making the base which is a super function
        base = super().__str__()
 
        # making a return statment with the string
        return (base +
                f"\nCampus: {self.campus}\n"
                f"Location: {self.room}\n"
                f"Capacity: {self.capacity}")
 
# making the main function
def main():
    # welcome message 
    print("--------------------------------")
    print("Welcome to course database main menu:")
    print("--------------------------------")
    
    # making a open of the text file
    import os, glob
    folder = os.path.dirname(os.path.abspath(__file__))
    matches = glob.glob(os.path.join(folder, "library.txt")) + sorted(glob.glob(os.path.join(folder, "courses*.txt")))
    if not matches:
        print("Could not find a courses text file in:", folder)
        print("Files in that folder:", os.listdir(folder))
        return
    with open(matches[0]) as f:
        # making a for loop of line
        for line in f:
            # skip any blank lines
            if not line.strip():
                continue
 
            # parts which line.strip
            parts = [x.strip() for x in line.strip().split(',')]
            
            # level of parts
            level = parts[0]
            
            # the id of courses
            course_id = parts[1]
            
            # title of the course
            title = parts[2]
            
            # instructor
            instructor = parts[3]
            
            # making the if statment of online
            if parts[4].lower() == "online":
                # online parts of the course
                Online(level, course_id, title, instructor)
            else:
                # campus which is fourth part
                campus = parts[4]
                
                # room which is 5
                room = parts[5]
                
                # the capicity which is 6th parts
                capacity = parts[6]
                
                # all of the needed information about the course 
                InPerson(level, course_id, title, instructor, campus, room, capacity)
    # making the menu
    menu = ("\nSearch by course title[t]\n"
            "Search by Instructor[i]\n"
            "Search by Level[l]\n"
            "Exit[e]")
    
    # choice is an empty list
    choice = ""
    
    # making the while loop which is not equal to a letter
    while choice != "e":
        # making the print menu statment
        print(menu)
        
        # having the user enter the choice
        choice = input("Enter choice (t/i/l/e): ").strip().lower()
        
        # making the try catch
        try:
            # making the if statment
            if choice == "t":
                # making the input statment for  the enter the title of course
                
                key = input("Enter course title: ").strip()
                # making the results of the courses that match the title = t 
                results  = Course.all_courses.search(key, 't')# t = title
                
                # making the if statment of the results
                if not results:
                    raise InvalidCourse()
                
                # making a for loop of results
                for l in results:
                    print(l)
            # making an elif statment of i
            elif choice == 'i':
                # making a key of the input where the user enters the instructor input
                key = input("Enter the instructor's name: ").strip()
                
                # results
                results = Course.all_courses.search(key, 'i')
                
                # making an if statment if the instructor names is not there
                if not results:
                    # rasing an course is not valid
                    raise InvalidInstructor()
                
                # making a for loop in results
                for c in results:
                    print(c)
                
            # making an elif choice
            elif choice == 'l':
                # making a key of entering the level of undergrad or grad
                key = input("Enter the level(UG/G): ").strip().upper()
                
                # making the results of the search of courses
                results = Course.all_courses.search(key, 'l')
                
                # making an if statme of results
                if not results:
                    # raising an InvalidLevel
                    raise InvalidLevel()
                
                # making a for loop of results
                for c in results:
                    # making a print statment c
                    print(c)
 
            # making an elif choice of e
            elif choice == 'e':
                print("Exiting the database...")
            # making a else statment if the user enters a wrong option
            else:
                raise InvalidOption()
        # making a expect block of invalid options
        except (InvalidCourse,
                InvalidInstructor,
                InvalidLevel,
                InvalidOption) as e:
            print(e)
main()